/*
 * Description: Collection of core functions for the modules in the camelot expansion.
 */
var CAMELOT = (function (self) {
	


    self.store = function () {
		return GDT.getDataStore("CAMELOT-EXP-PACK").data;
	};
    self.settings = function () {
        return GDT.getDataStore("CAMELOT-EXP-PACK").settings;
    };
    self.addSR = function (research) {
		UltimateLib.Research.addSpecialResearch(research);
	};
    self.addBR = function (research) {
		UltimateLib.Research.addRndResearch(research);
    };
    self.addHR = function (research) {
        UltimateLib.Research.addHardwareResearch(research);
    };
    self.post = function (post) {
		GameManager.company.notifications.push(post);
	};

    self.gC = function () {
		return GameManager.company;
	};
	
    self.setContextButtons = function () {
		var contextMenu = UI._showContextMenu;
		
			UI._showContextMenu = function(b, c, d, h){
			    self.addContextButtons(b, c);
				contextMenu(b, c, d, h);
			};
	};
	
	
    self.addContextButtons = function (screen, buttonArray) {
		CAMELOT.Grid.Interface.addButton(screen, buttonArray);
	};

    self.getShortNumberString = function () {
		//Overrides UI.getShortNumberString
		UI.getShortNumberString = function (number){
	
				var abNum = Math.abs(number);
				var fnum;
				
		        switch (true){
		        	case (abNum >= 1E24):
					fnum = "{0}SP".format(UI.getLongNumberString(Math.roundToDecimals(number / 1E24, 1)));
		        	break;
		        	case (abNum >= 1E21):
					fnum = "{0}SX".format(UI.getLongNumberString(Math.roundToDecimals(number / 1E21, 1)));
		        	break;
		        	case (abNum >= 1E18):
					fnum = "{0}QT".format(UI.getLongNumberString(Math.roundToDecimals(number / 1E18, 1)));
		        	break;
		        	case (abNum >= 1E15):
					fnum = "{0}QD".format(UI.getLongNumberString(Math.roundToDecimals(number / 1E15, 1)));
		        	break;
		        	case (abNum >= 1E12):
					fnum = "{0}T".format(UI.getLongNumberString(Math.roundToDecimals(number / 1E12, 1)));
		        	break;
		        	case (abNum >= 1E9):
					fnum = "{0}B".format(UI.getLongNumberString(Math.roundToDecimals(number / 1E9, 1)));
		        	break;
		        	case (abNum >= 1E6):
					fnum = "{0}M".format(UI.getLongNumberString(Math.roundToDecimals(number / 1E6, 1)));
		        	break;
		        	case (abNum >= 1E3):
					fnum = "{0}K".format(UI.getLongNumberString(Math.roundToDecimals(number / 1E3, 1)));
		        	break;
		        	case (abNum < 1E3):
					fnum = Math.roundToDecimals(number, 1);
		        	break;
		        	default:
		        	fnum = 0;
		        	console.log("error");
		        	console.log(abNum);
		        	break;
		        }
		        return fnum;
		  };
    };
        




    self.runStartUp = function () {

        self.setContextButtons();
        self.getShortNumberString();
        
    };
	
    return self;
})(CAMELOT || {});﻿/*
 * Description: Contracts addon module for Camelot.
 */
CAMELOT.Contracts = (function (self) {
    var cam = "CAMELOT";

    var modGame =   {
                        title: "Game Mod",
                        ulid: cam + "gameModding",
                        description: "Create some mods for a community to boost game sales.",
                        isRandom: false, // If true will be randomly added when contracts are requested (only if trigger conditions are met).
                        randomChance: 4, 
                        canTrigger: function (company) {
                            return company.gameLog.length > 5; // Bool value determining whether the contract can be taken or not.
                        },
                        complete: function (company) {
                        	company.fans = Math.floor(company.fans * 0.01);
                        },
                        repeatable: false,
                        requiredD: 10, // Design points required
                        requiredT: 8, // tech points required
                        payment: 2E3, // Payment on completion 
                        penalty: -2E2, // Penelty for not completing on time.
                        weeksToFinish: 2, // Number of weeks to complete the contract.
                        rF: 0.1, // Research Factor Standard Range: 0.2 - 1.5  
                        size: "small" //"small", "medium", or "large"

                    };

    var healthMon = {
        title: "Health Monitor",
        ulid: cam + "healthmon",
        description: "A private hospital chain require new health monitoring software.",
        isRandom: false, // If true will be randomly added when contracts are requested (only if trigger conditions are met).
        randomChance: 4,
        canTrigger: function (company) {
            return LevelCalculator.getMissionLevel("Engine") > 5; // Bool value determining whether the contract can be taken or not.
        },
        complete: function (company) {
        	company.flags.good += 1;
        },
        repeatable: false,
        requiredD: 15, // Design points required
        requiredT: 38, // tech points required
        payment: 1E5, // Payment on completion 
        penalty: -2E4, // Penelty for not completing on time.
        weeksToFinish: 2, // Number of weeks to complete the contract.
        rF: 1.5, // Research Factor Standard Range: 0.2 - 1.5  
        size: "medium" //"small", "medium", or "large"
    };

    var masa = {
        title: "MASA Simulation",
        ulid: cam + "masa",
        description: "MASA require a solar system simulator.",
        isRandom: false, // If true will be randomly added when contracts are requested (only if trigger conditions are met).
        randomChance: 4,
        canTrigger: function (company) {
            return LevelCalculator.getMissionLevel("World Design") > 5; // Bool value determining whether the contract can be taken or not.
        },
        complete: function (company) {

        },
        repeatable: false,
        requiredD: 45, // Design points required
        requiredT: 92, // tech points required
        payment: 1E5, // Payment on completion 
        penalty: -2E4, // Penelty for not completing on time.
        weeksToFinish: 2, // Number of weeks to complete the contract.
        rF: 2, // Research Factor Standard Range: 0.2 - 1.5  
        size: "large" //"small", "medium", or "large"
    };

    var webTemp = {
        title: "Website Templates",
        ulid: cam + "webTemp",
        description: "Make some website templates for WebTemplates Inc.",
        isRandom: true, // If true will be randomly added when contracts are requested (only if trigger conditions are met).
        randomChance: 2,
        canTrigger: function (company) {
            return company.gameLog.length > 2; // Bool value determining whether the contract can be taken or not.
        },
        complete: function (company) {
            
        },
        repeatable: true,
        requiredD: 10, // Design points required
        requiredT: 4, // tech points required
        payment: 1E3, // Payment on completion 
        penalty: -2E2, // Penelty for not completing on time.
        weeksToFinish: 1, // Number of weeks to complete the contract.
        rF: 0.1, // Research Factor Standard Range: 0.2 - 1.5  
        size: "small" //"small", "medium", or "large"

    };

    UltimateLib.Contracts.add(webTemp);
    UltimateLib.Contracts.add(modGame);
    UltimateLib.Contracts.add(healthMon);
    UltimateLib.Contracts.add(masa);

    return self;
})(CAMELOT.Contracts || {});﻿/*
 * Description: Publishers addon module for Camelot.
 */
CAMELOT.Publishers = (function (self) {
    var cam = "CAMELOT";


    var allforone = {
        ulid: cam + "all4one", //Contract ID
        name: "Self Publish",
        publisher: "All4One",
        isRandom: false, // If true will be randomly added when publisher contracts are requested (only if trigger conditions are met).
        randomChance: 10, // Will have a 1 in 10 chance of appearing in contract list
        canTrigger: function (company) {
            return true; // Bool value determining whether the contract can be taken or not.
        },
        complete: function (company) {

        },
        repeatable: true,
        gameSize: "small", // small???, medium, large, aaa??? mmo???
        gameAudience: "everyone", // young, everyone, or mature
        minScore: 3, // Score requirement
        payment: -1E5, // Payment for taking the contract 
        penalty: 0, // Pelenty charged if score requirement not met, should be higher than 
        royaltyRate: 0.3 // Decimal percentage of sales 
    };



    var phoneGame = {
        ulid : cam + "phoneGame", //Contract ID
        publisher : "Keasoft",
        isRandom: false, // If true will be randomly added when publisher contracts are requested (only if trigger conditions are met).
        randomChance: 10, // Will have a 1 in 10 chance of appearing in contract list
        canTrigger: function (company) {
            return company.gameLog.length > 3; // Bool value determining whether the contract can be taken or not.
        },
        complete: function (company) {
             // Bool value determining whether the contract can be taken or not.
        },
        repeatable: false,
        topic : "Comedy", // topic id or undefined for any topic
        genre : "Action", // genre id or undefined for any genre
        platform : "grPhone", // platform id or undefined for any platform
        gameSize : "small", // small, medium, large, aaa??? mmo???
        gameAudience : "everyone", // young, everyone, or mature
        minScore : 5, // Score requirement
        payment : 5E4, // Payment for taking the contract 
        penalty : -5E4, // Pelenty charged if score requirement not met, should be higher than 
        royaltyRate : 0.1 // Decimal percentage of sales 
    };

    var boringCorp = {
        ulid: cam + "boringCorp", //Contract ID
        publisher: "Boring Corp.",
        isRandom: false, // If true will be randomly added when publisher contracts are requested (only if trigger conditions are met).
        randomChance: 10, // Will have a 1 in 10 chance of appearing in contract list
        canTrigger: function (company) {
            return true; // Bool value determining whether the contract can be taken or not.
        },
        complete: function (company) {
            // Bool value determining whether the contract can be taken or not.
        },
        repeatable: false,
        topic: "Crime", // topic id or undefined for any topic
        genre: "Simulation", // genre id or undefined for any genre
        platform: "PC", // platform id or undefined for any platform
        gameSize: "medium", // small, medium, large, aaa??? mmo???
        gameAudience: "mature", // young, everyone, or mature
        minScore: 5, // Score requirement
        payment: 5E4, // Payment for taking the contract 
        penalty: -5E4, // Pelenty charged if score requirement not met, should be higher than 
        royaltyRate: 0.1 // Decimal percentage of sales 
    };
/*
    var boringCorp2 = {
        ulid: cam + "boringCorp2", //Contract ID
        publisher: "Boring Corp.",
        isRandom: false, // If true will be randomly added when publisher contracts are requested (only if trigger conditions are met).
        randomChance: 10, // Will have a 1 in 10 chance of appearing in contract list
        canTrigger: function (company) {
            return true; // Bool value determining whether the contract can be taken or not.
        },
        complete: function (company) {
            // Bool value determining whether the contract can be taken or not.
        },
        repeatable: false,
        topic: "Astronaut", // topic id or undefined for any topic
        genre: "Simulation", // genre id or undefined for any genre
        platform: "PC", // platform id or undefined for any platform
        gameSize: "AAA", // small, medium, large, aaa??? mmo???
        gameAudience: "mature", // young, everyone, or mature
        minScore: 5, // Score requirement
        payment: 5E6, // Payment for taking the contract 
        penalty: -5E6, // Pelenty charged if score requirement not met, should be higher than 
        royaltyRate: 0.1, // Decimal percentage of sales 
    };
    
    var magex = {
        ulid: cam + "Magex", //Contract ID
        publisher: "Magex",
        isRandom: false, // If true will be randomly added when publisher contracts are requested (only if trigger conditions are met).
        randomChance: 10, // Will have a 1 in 10 chance of appearing in contract list
        canTrigger: function (company) {
            return true; // Bool value determining whether the contract can be taken or not.
        },
        complete: function (company) {
            // Bool value determining whether the contract can be taken or not.
        },
        repeatable: false,
        topic: "Comedy", // topic id or undefined for any topic
        genre: "Action", // genre id or undefined for any genre
        platform: "PC", // platform id or undefined for any platform
        gameSize: "MMO", // small, medium, large, aaa??? mmo???
        gameAudience: "everyone", // young, everyone, or mature
        minScore: 5, // Score requirement
        payment: 5E4, // Payment for taking the contract 
        penalty: -5E4, // Pelenty charged if score requirement not met, should be higher than 
        royaltyRate: 0.1, // Decimal percentage of sales 
    };
*/

    UltimateLib.Publishers.add(allforone);
    UltimateLib.Publishers.add(phoneGame);
    UltimateLib.Publishers.add(boringCorp);



    return self;
})(CAMELOT.Publishers || {});/*
 * Description: Debugging addon module for Camelot.
 */
CAMELOT.Debug = (function (self) {

	/*
	 * Short Hand Variables
	 */
	var evKey = GDT.eventKeys.gameplay;

	/*
	 * Researches
	 */
	var effRSearch = {
		id: "DebuggingMethodResearch",
		name: "Debugging Methods".localize(),
		pointsCost: 150,
		duration: 3E4,
		cost: 50E4,
		canResearch: function (a) {
			return (a.staff.length > 2 && CAMELOT.store().effRS !== true);
		},
		category: "Debugging",
		categoryDisplayName: "Debugging".localize(),
		complete: function () {
			CAMELOT.store().effRS = true;
			CAMELOT.store().bugRate += 2;
			CAMELOT.post(new Notification({
				header: "Debugging Methods".localize(),
				text: "Top Notch. Now we can debug our games much faster!".localize()
			}));
		}
	};
	var monRSearch = {
		id: "DebugMonkeyCheckers",
		name: "Monkey Checkers".localize(),
		pointsCost: 300,
		duration: 4E4,
		cost: 80E4,
		canResearch: function (a) {
		    return (a.staff.length > 5 && CAMELOT.store().monRS !== true && CAMELOT.store().effRS === true);
		},
		category: "Debugging",
		categoryDisplayName: "Debugging".localize(),
		complete: function (company) {
			CAMELOT.store().monRS = true;
			CAMELOT.store().bugRate += 2;
			CAMELOT.post(new Notification({
				header: "Monkey Checkers Unite!".localize(),
				text: "Huge schools of monkeys will now help check over some of your codes making debugging much faster!".localize()
			}));
		}
	};
	var aiDebugger = {
		id: "BugResearch.AI-Debugger",
		name: "AI-Debugger".localize(),
		pointsCost: 10000,
		canResearch: function (company) {
			return (CAMELOT.store().aiDB !== true && CAMELOT.store().monRS === true);
		},
		iconUri: "./mods/Camelot/img/debug/aibug.png",
		description: "An AI-dubugging algorithm thats great at finding lots of bugs quickly, written by those friendly guys at SkiiNet.".localize(),
		complete: function () {
		    CAMELOT.store().bugRate += 10;
		    CAMELOT.store().aiDB = true;
			CAMELOT.post(new Notification({
				header: "AI-DEBUGGER".localize(),
				text: "AI-DEBUGGER ONLINE!".localize()
			}));
		}
	};

	var roboBugger = {
	    id: "BugResearch.roboBugger",
	    name: "Robo-Bugger".localize(),
	    pointsCost: 40000,
	    canResearch: function (company) {
	        return (CAMELOT.store().roboBug !== true && CAMELOT.store().aiDB === true);
	    },
	    iconUri: "./mods/Camelot/img/debug/robobug.png",
	    description: "An friendly debugging robot, built by those friendly guys at SkiiNet.".localize(),
	    complete: function () {
	        CAMELOT.store().bugRate += 20;
	        CAMELOT.store().roboBug = true;
	        CAMELOT.post(new Notification({
	            header: "ROBO-DEBUGGER".localize(),
	            text: "Judg... Debugging Day is here!".localize()
	        }));
	    }
	};

	/*
	 * Debug Methods
	 */
	self.addBugRate = function () {
		var appendMe = GameManager.decreaseBugs;
		GameManager.decreaseBugs = function (b) {
			if (CAMELOT.store().CErunOnce !== true) {
	            CAMELOT.store().bugRate = 1;
	            CAMELOT.store().CErunOnce = true;
	        }		
			if (CAMELOT.gC().currentGame.bugs <= CAMELOT.store().bugRate * 7) {
				b = 1;
			} else {
				b = CAMELOT.store().bugRate;
			}	
			appendMe(b);
		};
	};

	self.addBugResearch = function () {
	    CAMELOT.addSR(monRSearch);
	    CAMELOT.addSR(effRSearch);
	    CAMELOT.addBR(aiDebugger);
	    CAMELOT.addHR(roboBugger);
	};

	self.runStartUp = function () {
	    self.addBugResearch();
		self.addBugRate();
	};


	return self;
})(CAMELOT.Debug || {});﻿/*
 * Version: 0.1.0
 * Description: Additional game modes
 * 
 */
CAMELOT.GameMode = (function (self) {

    self.addGameModeSelector = function () {
        var draw = "";
        draw += '<div id="gameMode" class="centeredButtonWrapper">';
        draw += '<h2>Game Mode</h2>';
        draw += '</ br>';
        draw += '<select id="gmSelect" style="max-width: 250px">';
        draw += '<option value="normal" selected="selected">Normal</option>';
        draw += '<option value="oneman">One Man Machine</option>';
        draw += '</select>';
        draw += '<p>One Man Machine: Never leave the garage. How long can you keep up with everyone else.</p>';
        draw += '</div>';
        UltimateLib.Configuration.addAdvancedOption(draw);
    };

    self.setGameMode = function () {
        var keepMe = UI.closeNewGameView;
        var inputMe = function () {
            var findMe = document.getElementById("gmSelect").value;
            switch (findMe) {
                case "oneman":
                    oneMan();
                    break;
                case "sandbox":
                    break;
                case "normal":
                    //CAMELOT.store().gameMode = "normal";
                    break;
                default:
                    break;
            }
        };

        UI.closeNewGameView = function () {
            keepMe();
            inputMe();
        };
    };

    function oneMan (){
        DecisionNotifications.moveToLevel2.trigger = null;
        CAMELOT.store().gameMode = "oneman";
    }

        /*
    function moveToLevel4() {

        if (GameManager.company.gameLog.length == 0) {
            GameManager.company.notifications.push(new Notification("CheatMod", "To continue to the final level, you need to have at least created game 1 game"));
            return
        }

        if (GameManager.company.currentLevel != 4) {

            //add at least 1 staff member & at least 1 game
            if (GameManager.company.staff.length < 2) {
                GameManager.company.maxStaff = 7;
                //addDreamTeam();
                var character = new Character({
                    id: GameManager.getGUID(), name: "Cheater1", dF: 2,
                    tF: 2, speedF: 2, qualityF: 1, experience: 10000,
                    researchF: 2, salary: 1, efficiency: 1,
                    slot: 2, sex: 1
                });

                GameManager.setBodyAndHead(character);
                character.flags.hiredTimestamp = GameManager.gameTime;
                character.flags.nextVacation = GameManager.gameTime + 48E3 * GameManager.SECONDS_PER_WEEK;
                character.flags.workload = 0;
                GameManager.company.staff.push(character);
                GameManager.uiSettings.findStaffData = null;
                VisualsManager.reloadAllCharacters();
                GameManager.company.staff[GameManager.company.staff.length - 1].startAnimations();
                VisualsManager.addComputer(character);
                VisualsManager.refreshHiringButtons();
                VisualsManager.refreshTrainingOverlays();
            }
            GameManager.company.currentLevel = 4,
			VisualsManager.nextLevel();
            Media.createLevel4Notifications();
            GameManager.save(GameManager.company.slot + "L4");
            GameManager.resume(true);
        }
        unlockRnDLab();
        unlockHwLab();
    }

    function unlockHwLab() {
            GameManager.company.flags.hwLabUnlocked = true;
            //GameManager.company.flags.hwBudget = 0;
            GameManager.company.flags.fractionalHwLabCosts = 0;
    }

    function unlockRnDLab() {
            GameManager.company.flags.rndLabUnlocked = true;
            //GameManager.company.flags.rndBudget = 0;
            //GameManager.company.flags.fractionalRndLabCosts = 0;
    }
    */

    self.checkGameMode = function () {
        switch (CAMELOT.store().gameMode) {
            case "oneman":
                oneMan();
                break;
            case "sandbox":
                break;
            case "normal":
                //CAMELOT.store().gameMode = "normal";
                break;
            default:
                break;
        }

    };

    self.setCheckGameMode = function () {
        GDT.on(GDT.eventKeys.saves.loading, self.checkGameMode);
    };


    self.runStartUp = function () {
        self.addGameModeSelector();
        self.setGameMode();
        self.setCheckGameMode();
    };

    return self;
})(CAMELOT.GameMode || {});/*
 * Description: Collection of core functions for the modules in the camelot expansion.
 */
CAMELOT.MiscFeatures = (function (self) {
		
    self.addGameExtentions = function () {
    	
        var findMe = document.getElementById("gameLengthSelection");
        var appendMe = document.createElement("option");
        appendMe.text = "50 Years (long)";
        appendMe.value = 1.66667;
        findMe.appendChild(appendMe);

        findMe = document.getElementById("gameLengthSelection");
        appendMe = document.createElement("option");
        appendMe.text = "60 Years (extra long)";
        appendMe.value = 2;
        findMe.appendChild(appendMe);

        findMe = document.getElementById("gameLengthSelection");
        appendMe = document.createElement("option");
        appendMe.text = "88 Years (1.21 gigawattz!)";
        appendMe.value = 2.93334;
        findMe.appendChild(appendMe);

        findMe = document.getElementById("gameLengthSelection");
        appendMe = document.createElement("option");
        appendMe.text = "100 Years (neverending story)";
        appendMe.value = 3.36667;
        findMe.appendChild(appendMe);
        
    };
    
    self.earlySequels = function () {
        var r = Research.Sequels;
        r.pointsCost = 5;
        r.devCost = 500;
        r.canResearch = function (c) { return c.gameLog.length >= 1; };
    };


    
    self.visualTweaks = function () {
    	if (UltimateLib.Storage.read("CamelotVisuals") === true) {
    		UltimateLib.Visuals.Tweaks.setAllTweaks();
    		setWatermarks();

    	}
   	};
        
    
   	self.setFSPHeight = function () {
   	    var find = $("#newGameView");
   	    find.find(".featureSelectionPanel").height = 600;
   	};

   	self.addGameEngineField = function () {
   	    //var findme = $('#gameDetailsTemplate');
   	    var appendme = $('<div class="gameDetailsEngineLabel gameDetailsColumn1">Game Engine:</div><div class="gameDetailsEngine gameDetailsColumn2"></div>');

   	    appendme.insertAfter('.gameDetailsTotal');
   	};

   	self.setGameEngineField = function () {
   	    var keepme = UI._getElementForGameDetail;

   	    UI._getElementForGameDetail = function (game, avgReview) {
   	        var aret = keepme(game, avgReview);
   	        if (game.engine === null || game.engine === undefined) {
   	            aret.find('.gameDetailsEngine').text("None");
   	        } else {
   	            aret.find('.gameDetailsEngine').text(game.engine.name);
   	        }
   	        
   	        aret.find('.gameDetailsEngineLabel').css('position','absolute');
   	        aret.find('.gameDetailsEngineLabel').css('top', '172px');
   	        aret.find('.gameDetailsEngine').css('position', 'absolute');
   	        aret.find('.gameDetailsEngine').css('top', '175px');
            
   	        var mod = 30;
   	        var top = 172;
   	        var top2 = 175;
   	        aret.find('.gameDetailsReleaseWeekLabel').css('top', top += mod);
   	        aret.find('.gameDetailsReleaseWeek').css('top', top2 += mod);
   	        aret.find('.gameDetailsFansChangeLabel').css('top', top += mod);
   	        aret.find('.gameDetailsFansChange').css('top', top2 += mod);
   	        aret.find('.gameDetailsAvgReviewLabel').css('top', top += mod);
   	        aret.find('.gameDetailsAvgReview').css('top', top2 += mod);
   	        aret.find('.gameDetailsTopSalesRankLabel').css('top', top += mod);
   	        aret.find('.gameDetailsTopSalesRank').css('top', top2 += mod);

   	        return aret;
   	    };



   	};

   	function setWatermarks() {

   	    UltimateLib.VisualTweaks.setWatermarks("slider-engine-img", ".\/mods\/Camelot\/img\/sliderpics\/gear.gif");
   	    UltimateLib.VisualTweaks.setWatermarks("slider-gameplay-img", ".\/mods\/Camelot\/img\/sliderpics\/gameplay.gif");
   	    UltimateLib.VisualTweaks.setWatermarks("slider-story-img", ".\/mods\/Camelot\/img\/sliderpics\/story.gif");

   	    UltimateLib.VisualTweaks.setWatermarks("slider-dialogs-img", ".\/mods\/Camelot\/img\/sliderpics\/dialog.gif");
   	    UltimateLib.VisualTweaks.setWatermarks("slider-level-img", ".\/mods\/Camelot\/img\/sliderpics\/level.gif");
   	    UltimateLib.VisualTweaks.setWatermarks("slider-ai-img", ".\/mods\/Camelot\/img\/sliderpics\/ai.gif");

   	    UltimateLib.VisualTweaks.setWatermarks("slider-world-img", ".\/mods\/Camelot\/img\/sliderpics\/world.gif");
   	    UltimateLib.VisualTweaks.setWatermarks("slider-graphic-img", ".\/mods\/Camelot\/img\/sliderpics\/graphics.gif");
   	    UltimateLib.VisualTweaks.setWatermarks("slider-sound-img", ".\/mods\/Camelot\/img\/sliderpics\/sound.gif");

   	}

   	self.createCamelotConfig = function () {

   		var visuals = true;
   		console.log(UltimateLib.Storage.read("CamelotVisuals"));
   		try {
   			if (UltimateLib.Storage.read("CamelotVisuals") === null) {
				UltimateLib.Storage.write("CamelotVisuals", true);
   			}

   			visuals = UltimateLib.Storage.read("CamelotVisuals");
   			console.log("try");
   		} catch (e) {
   			UltimateLib.Storage.write("CamelotVisuals", visuals);
   			console.log("catch");
   		}

   		var content = '' +
			'<div class="windowTitle smallerWindowTitle">Visuals</div>' +
            '<div>' +
            '<input type="checkbox" name="camelot-Visuals-toggle" id="camelot-Visuals-toggle" class="css-checkbox" checked="' + visuals + '" />' +
			'<label for="camelot-Visuals-toggle" class="css-label">Custom UI Toggle</label>' +
            '<br />' +
            '<small>Turn Camelot\'s custom UI off. Requires restart.</small>' +
            '</div>';



   		UltimateLib.Configuration.addTab("CAMELOT-Config", "Camelot", content);
   		$("#camelot-Visuals-toggle").change(function () {
   			UltimateLib.Storage.write("CamelotVisuals", $(this).is(":checked"));
   		});
   	};

   	self.runStartUp = function () {
   		self.createCamelotConfig();
        self.addGameExtentions();
    	self.visualTweaks();
    	self.addGameEngineField();
    	self.earlySequels();

    };
    
    return self;
})(CAMELOT.MiscFeatures || {});

/*
 * Version: 0.1.0
 * Description: Specialism addon for Camelot
 *
 */
CAMELOT.Specialism = (function (self) {

    self.addSpecialismOption = function () {
		var draw = "";
		draw += '<div id="specialism" class="centeredButtonWrapper">';
		draw += '<h2>Specialism</h2>';
		draw += '</ br>';
		draw += '<select id="spSelect" style="max-width: 250px">';
		draw += '<option value="design">Design++</option>';
		draw += '<option value="normal" selected="selected">Normal</option>';
		draw += '<option value="normalPlus">Normal+</option>';
		draw += '<option value="tech">Technology++</option>';
		draw += '</select>';
		draw += '<p>Increase your abilities at the start of the game</p>';
		draw += '</div>';
		UltimateLib.Configuration.addAdvancedOption(draw);
	};
	self.setSpecialism = function () {
		var keepMe = UI.closeNewGameView;
		var inputMe = function () {
			var findMe = document.getElementById("spSelect").value;
			switch (findMe) {
			case "design":
				CAMELOT.gC().staff[0].designFactor += (0.3);
				CAMELOT.gC().staff[0].technologyFactor -= (0.1);
				break;
			case "tech":
				CAMELOT.gC().staff[0].technologyFactor += (0.3);
				CAMELOT.gC().staff[0].designFactor -= (0.1);
				break;
			case "normalPlus":
				CAMELOT.gC().staff[0].technologyFactor += (0.15);
				CAMELOT.gC().staff[0].designFactor += (0.15);
				break;
			case "normal":
				break;
			default:
				console.log("Special Errored");
				break;
			}
                //CAMELOT.store().specialismSet = true;
		};

		UI.closeNewGameView = function () {
			keepMe();
			inputMe();
		};

	};

	self.runStartUp = function () {
	    self.addSpecialismOption();
		self.setSpecialism();
	};

	return self;
})(CAMELOT.Specialism || {});/*
 * Version: 0.1.0
 * Description: Collection of core functions for the modules in the camelot expansion.
 *
 */
CAMELOT.StartingMoney = (function (self) {

    self.addMoneyOption = function () {
        var draw = "";
        draw += '<div id="startingMoney" class="centeredButtonWrapper">';
        draw += '<h2>Starting Money</h2>';
        draw += '</ br>';
        draw += '<select id="moneySelect" style="max-width: 250px">';
        draw += '<option value="0">40k.</option>';
        draw += '<option value="1" selected>70k.*</option>';
        draw += '<option value="2">100k.</option>';
        draw += '<option value="3">250k.</option>';
        draw += '<option value="4">500k.</option>';
        draw += '<option value="5">1M.</option>';
        draw += '<option value="6">10M.</option>';
        draw += '<option value="7">100M.</option>';
        draw += '</select>';
        draw += '<p>*Default amount of money</p>';
        draw += '</div>';
        UltimateLib.Configuration.addAdvancedOption(draw);
    };
    self.setMoney = function () {
        var keepMe = UI.closeNewGameView;
        var inputMe = function () {
            var findMe = $("#moneySelect").val();
            CAMELOT.gC().flags.lastMoveUpLevelQ = true;
            switch(findMe){
                case "0":
                    CAMELOT.gC().cash = 4E4;
                    console.log("setMoney 0");
                    break;
                case "1":
                    console.log("setMoney 1");
                    break;
                case "2":
                    CAMELOT.gC().cash = 1E5;
                    console.log("setMoney 2");
                    break;
                case "3":
                    CAMELOT.gC().cash = 25E4;
                    console.log("setMoney 3");
                    break;
                case "4":
                    CAMELOT.gC().cash = 5E5;
                    console.log("setMoney 4");
                    break;
                case "5":
                    CAMELOT.gC().cash = 1E6;
                    console.log("setMoney 5");
                    break;
                case "6":
                    CAMELOT.gC().cash = 1E7;
                    console.log("setMoney 6");
                    break;
                case "7":
                    CAMELOT.gC().cash = 1E8;
                    console.log("setMoney 7");
                    break;
                default:
                    console.log("setMoney Error");
                    break;
            }

        };

        UI.closeNewGameView = function () {
            keepMe();
            inputMe();
            CAMELOT.store().sNOc = 0;
        };

    };

    self.stopNewOffice = function () {
        if (CAMELOT.store().sNOc !== 1){ CAMELOT.store().sNOc += 1; return;}
        if (CAMELOT.store().NOrunonce !== true){
        CAMELOT.gC().flags.lastMoveUpLevelQ = false;
        CAMELOT.store().NOrunonce = true;
        }
        GDT.off(GDT.eventKeys.gameplay.weekProceeded, self.stopNewOffice);
    };

    self.runStartUp = function () {
        self.addMoneyOption();
        self.setMoney();
        GDT.on(GDT.eventKeys.gameplay.weekProceeded, self.stopNewOffice);
    };

    return self;
})(CAMELOT.StartingMoney || {});/*
 * Version: 0.1.0
 * Description: Core functions of the Grid Expansion Module
 *
 */
CAMELOT.Grid = (function (self) {

    //Intialise variables
    self.setGridValues = function () {
        var s = CAMELOT.store();
        if (s.gridSet === true) { return; }
        s.gridNewCPer = 50;
        s.gridMarkPer = 25;
        s.gridMainPer = 50;
        s.gridExpenditure = 0;
        s.gridExpPer = 0;
        s.gridSet = true;
    };

    //Slider updates
    self.updateGridCost = function (value) {
        var tenP = CAMELOT.gC().cash * 0.025;
        var ex = tenP * (value / 100);
        ex = Math.floor(ex);

        CAMELOT.store().gridExpPer = value;
        CAMELOT.store().gridExpend = ex;
        $("#gridInterface").find("#gridExpendCost").html(UI.getShortNumberString(ex) + " Cr.");
    };
    self.updateNCCost = function (value) {
        CAMELOT.store().gridNewCPer = value;
    };
    self.updateMarkCost = function (value) {
        CAMELOT.store().gridMarkPer = value;
    };
    self.updateMainCost = function (value) {
        CAMELOT.store().gridMainPer = value;
    };

    //Percentage Values/Slider Values
    self.expPer = function () {
        return CAMELOT.store().gridExpPer;
    };
    self.ncPer = function () {
        return CAMELOT.store().gridNewCPer;
    };
    self.markPer = function () {
        return CAMELOT.store().gridMarkPer;
    };
    self.mainPer = function () {
        return CAMELOT.store().gridMainPer;
    };

    function overrideGridComplete() {
    	var keepme = Research.grid.complete;
    	Research.grid.complete = function (company) {
    		keepme(company);
    		var msg = "You can access the Grid controls from the GameDevTycoon context menu.";

    		var noty = new Notification("Grid Tutorial", msg);
    		noty.image = "./mods/Camelot/img/grid/gridTut.png";
    		company.notifications.push(noty);

    	};
		

    }

    function salesOverride() {
    	var keepme = General.proceedOneWeek;

    	General.proceedOneWeek = function (company, fractionalWeek) {

    		var grid = company.flags.grid;

    		company.flags.grid = false;

    		if (grid === true && company.getDate(company.currentWeek).week === 1 && company.currentWeek > 0) {
    			self.Sales.calculateSales(company);
    		}

    		keepme(company, fractionalWeek);

    		company.flags.grid = grid;

    	};

    };

    self.runStartUp = function () {
    	overrideGridComplete();
        self.setGridValues();
        salesOverride();
        self.Interface.runStartUp();
    };

    /** Grid Sales **/
    self.Sales = (function (self) {

        /*
        
        Equation notey-note note notes
        
        More NewContent =  More "potential revenue"
        
        Game log sales 1% = Base potential revenue
        
        NewContent(randomised) Potential Revenue
        
        TPR
        
        Potential revnue  -modifier affected by maintenence, affect by amount of games made 
        +modifier affected by marketing, affected by fans.
                     
        */

        self.calculateSales = function (company) {

            if (!(company.gameLog.length >= 1)) { return; }

            var bw = CAMELOT.Grid.Interface.budgetWeightings(); // nc mark main
            var ex = CAMELOT.store().gridExpend; // Grid expenditure cash

            var ncPer = bw[0] / 100; 	// Percentage of New Content
            var markPer = bw[1] / 100; // += % of Marketing
            var mainPer = bw[2] / 100; // -= % of Maintenence

            var ncEx = calculateNewContentExp(ncPer, ex);  	// New Content Expendititure
            var markEx = calculateMarketExp(markPer, ex);  // Marketing expend
            var mainEx = calculateMainExp(mainPer, ex); 	// Maintenence expend

            var totRev = totalRevenue(); // Total up revenue of all games.

            var fans = company.fans;

            var potInc = totRev * 0.0025; // 0.25% of all revenue from games is base potential income

            potInc += calculateNewContent(ncEx) * self.newContentMod();

            potInc += 5 * ((fans * 0.1) * markPer);
            potInc *= (1 - mainPer); // New Content sales. + Marketing Mod - Maintenence Mod

            var lastWeek = CAMELOT.store().lastWeekPotInc; // Get last weeks potential income

            // Return Income and Expenditure for the week
            if (lastWeek > 0) {
                company.adjustCash(lastWeek, "Grid Income"); //Check potential income is not null/undefined.
            }

            if (ex >= 0) {
                company.adjustCash(ncEx * -1, "Grid Maintenece");
                company.adjustCash(markEx * -1, "Grid Marketing");
                company.adjustCash(mainEx * -1, "Grid Content");

                lastWeek = Math.floor(potInc); // Store this weeks potential income for next week.
                CAMELOT.store().lastWeekPotInc = lastWeek;
            }

        };

        self.newContentMod = function () {
            var a = CAMELOT.store().ncMod;
            if (a > 0) { return a; }
            CAMELOT.store().ncMod = 1;
            return CAMELOT.store().ncMod;
        };

        function calculateNewContentExp(nc, ex) {
            if (nc === 0) { return nc; }
            //nc = UltimateLib.Utils.getFormattedNumber(nc);
            return ex * nc;
        }

        function calculateMarketExp(mark, ex) {
            if (mark === 0) { return mark; }
            //mark = UltimateLib.Utils.getFormattedNumber(mark);
            return ex * mark;
        }

        function calculateMainExp(main, ex) {
            if (main === 0) { return main; }
            //main = UltimateLib.Utils.getFormattedNumber(main);
            return ex * main;
        }

        function calculateNewContent(nex) {

            var nc = Math.floor(nex * (CAMELOT.gC().gameLog.length / 10000));
            // New Content amount NCSpending * ((amount of games already made) / 1000)

            if (nc < 5) { nc = 5; } // Check at least five new products are potential available.

            nc = Math.floor((Math.random() * nc) + 1); // Generate new product amounts

            var newgames = [];

            for (var i = 0; i < nc; i++) {
                newgames.push(Math.floor((Math.random() * 11) + 1)); // Create scores for each new product
            }

            var ncTot = 0;
            nex /= 20;
            for (var j = 0; j < newgames.length; j++) {
                ncTot += nex * (newgames[j] / Math.floor((Math.random() * 50) + 10));
                // Calculate income from new content base on ratings.
            }

            return Math.floor(ncTot);
        }

        function totalRevenue() {
            var totRev = 0;
            // Total Revenue of all games
            for (var i = 0; i < CAMELOT.gC().gameLog.length; i++) {
                totRev += CAMELOT.gC().gameLog[i].revenue;
                // Add up revenue of all games.
            }
            return totRev;
        }

        return self;
    })(self.Sales || {});

    /** Grid Interface **/
    self.Interface = (function (self) {
        self.setGridWindow = function () {

            var gridHtml = '' +
            '<div id="gridInterface" class="windowBorder tallWindow" style="overflow:none;display:none;">' +
                '<div id="gridInterfaceOverlay"></div>' +
                    '<div id="gridInterfaceContent">' +
                    '<div id="gridInterfaceTitle" class="windowTitle smallerWindowTitle">Grid Budget</div>' +
                    '<div class="focusSliderContainer">' +
                        '<div class="focusSliderWrapper newCon">' +
                        '<div id="newCon" class="focusSlider newCon"></div>' +
                        '<div class="focusSliderTitle">New Content</div>' +
                    '</div>' +
                '<div class="focusSliderWrapper market">' +
                    '<div id="market" class="focusSlider market"></div>' +
                    '<div class="focusSliderTitle">Marketing</div>' +
                '</div>' +
                    '<div class="focusSliderWrapper main">' +
                    '<div id="main" class="focusSlider main"></div>' +
                    '<div class="focusSliderTitle">Maintenance</div>' +
                '</div>' +
                    '</div>' +
                    '</div>' +
                '<div class="budgetDurationPreviewContainer">' +
                     '<div class="budgetDurationPreviewTitle">Budget Allocation</div>' +
                     '<div class="budgetDurationPreviewWrapper ul-vt-bar">' +
                        '<div class="budgetDurationPreview newConPreview ul-vt-bar-left"></div>' +
                        '<div class="budgetDurationPreview marketPreview"></div>' +
                        '<div class="budgetDurationPreview mainPreview ul-vt-bar-right"></div>' +
                     '</div>' +
                '</div>' +
                '<div class="centeredButtonWrapper" style="margin-top: 20px">' +
                    '<h2>Expenditure Cost: </h2><h2 id="gridExpendCost">0 Cr.</h2>' +
                    '<div id="expenditureSlider" class="volumeSlider"></div>' +
                    '</div>' +
                '</div>' +
				/*
                '<div class="featureSelectionPanel featureSelectionShowState">' +
                    '<div class="windowTitle smallerWindowTitle">Title</div>' +
                '</div>' +
				*/
            '</div>';

            $("body").append(gridHtml);
            var importme = document.createElement('link');
            importme.id = 'gridCss';
            importme.rel = 'stylesheet';
            importme.type = 'text/css';
            importme.href = 'mods/Camelot/css/grid.css';
            document.getElementsByTagName('head')[0].appendChild(importme);

        };

        self.addButton = function (screen, buttonArray) {
            if (GameManager.company.flags.grid === true && screen == "primary") {
                buttonArray.push({
                    label: "Grid...".localize("menu item"),
                    action: function () {
                        Sound.click();
                        self.showGridWindow();
                    }
                });
            }
        };

        self.showGridWindow = function () {

            var draw = $('#gridInterface');
            self.updateFocusPreview();
            draw.scrollTop();
            draw.gdDialog({
                popout: !0,
                close: !0,
                onClose: function () {
                    GameManager.togglePause();
                },
                onOpen: function () {
                    GameManager.togglePause();
                    GameManager.resume(!0);
                }
            });

            draw.find("#gridExpendCost").html(UI.getShortNumberString(CAMELOT.store().gridExpend) + " Cr.");

            draw.find("#expenditureSlider").slider({
                min: 0,
                max: 100,
                range: "min",
                value: CAMELOT.Grid.expPer(),
                animate: false,
                slide: function (a, b) {
                    var c = b.value;
                    CAMELOT.Grid.updateGridCost(c);
                    delayUpdate();
                    //GridInterface.updateFocusPreview();
                }
            });

            draw.find("#newCon").slider({
                orientation: "vertical",
                min: 0,
                max: 100,
                range: "min",
                value: CAMELOT.Grid.ncPer(),
                animate: false,
                slide: function (a, b) {
                    var c = b.value;
                    CAMELOT.Grid.updateNCCost(c);
                    delayUpdate();
                    //GridInterface.updateFocusPreview();
                }
            });

            draw.find("#market").slider({
                orientation: "vertical",
                min: 0,
                max: 100,
                range: "min",
                value: CAMELOT.Grid.markPer(),
                animate: false,
                slide: function (a, b) {
                    var c = b.value;
                    CAMELOT.Grid.updateMarkCost(c);
                    delayUpdate();
                    //GridInterface.updateFocusPreview();
                }
            });

            draw.find("#main").slider({
                orientation: "vertical",
                min: 0,
                max: 100,
                range: "min",
                value: CAMELOT.Grid.mainPer(),
                animate: false,
                slide: function (a, b) {
                    var c = b.value;
                    CAMELOT.Grid.updateMainCost(c);
                    delayUpdate();
                    //GridInterface.updateFocusPreview();
                }
            });

        };

        self.updateFocusPreview = function () {
            wa = self.budgetWeightings();

            nc = wa[0];
            mk = wa[1];
            mn = wa[2];

            f = $(".budgetDurationPreviewWrapper");

            a = $(".newConPreview");
            b = $(".marketPreview");
            c = $(".mainPreview");

            w = 524 * (CAMELOT.Grid.expPer() / 100);

            a.width(nc / 100 * w);
            b.width(mk / 100 * w);
            c.width(mn / 100 * w);
        };

        self.budgetWeightings = function () {

            var featureWeighting = [CAMELOT.Grid.ncPer(), CAMELOT.Grid.markPer(), CAMELOT.Grid.mainPer()];

            var minValuePerFeature = 1;

            var total = featureWeighting.sum();

            if (total === 0) {
                return [100 / 3, 100 / 3, 100 / 3];
            }

            var finalValues = featureWeighting.map(function (v) {
                return v / (total / (100 - minValuePerFeature * 3)) + minValuePerFeature;
            });

            return finalValues;
        };


        function delayUpdate() {
            GameManager.addTickListener(self.updateFocusPreview, false);
        }



        self.runStartUp = function () {
            self.setGridWindow();
        };


        return self;
    })(self.Interface || {});



    return self;
})(CAMELOT.Grid || {});/*
 * Version: 0.1.0
 * Description: Adds staff training options.
 * TODO: Make this automatic, depicted by animation
 */
CAMELOT.Train = (function (self) {
	
	/*
	 * Short Hand Variables
	 */
	var evKey = GDT.eventKeys.gameplay;
	
	self.EventTrain = function () {
        if (Math.floor((Math.random() * 4) + 1) != 1) {
            return;
        }
        var game = CAMELOT.gC().gameLog.last();
        var staffMember = CAMELOT.gC().staff.skip(0).pickRandom();
        var staffName = staffMember.name;
        var statAmount = Math.floor((Math.random() * 15) + 3);
        var stat = Math.floor((Math.random() * 4) + 1);
        var sv = statAmount / 500;
        switch (stat) {
        case 1:
            staffMember.designFactor += sv;
            stat = "Design";
            break;
        case 2:
            staffMember.technologyFactor += sv;
            stat = "Technology";
            break;
        case 3:
            staffMember.speedFactor += sv;
            stat = "Speed";
            break;
        case 4:
            staffMember.researchFactor += sv;
            stat = "Research";
            break;
        default:
            CAMELOT.post(new Notification("Train Event".localize(), "Trained event errored."));
            break;
        }
        var message = "Whilst working on " + game.title + " " + staffName + " improved their " + stat + " ability by " + statAmount + "!".localize().format(staffMember.name);
        CAMELOT.post(new Notification("Staff Improved!".localize(), message));
    };
    
    self.runStartUp = function () {
        GDT.on(evKey.afterReleaseGame, self.EventTrain);
    };
    
    return self;
})(CAMELOT.Train || {});/*
 * Description: Core Methods for the Stock Market
 * 
 */
CAMELOT.StockMarket = (function (self) {
	
	var evKey = GDT.eventKeys.gameplay;
	
	self.getStockPrice = function () {
		
		var stockPrice; // StockPrice = 
						// (company's earnings*company's constant growth rate/(company's risk adjusted discount rate*company's risk adjusted discount rate))+
						// (company's dividend payment/company's risk adjusted discount rate)
		
		var com = CAMELOT.gC();
		var staff = com.staff.length; // 1 - 7
		
		var lastGame = com.gameLog.last();
		var gRating = Math.floor(lastGame.score);
		
		var earning = com.cash;
		var prevEarn = CAMELOT.store().SMearnings;
		var growth = earning - prevEarn;	
		var stockMod = CAMELOT.store().SMstockMod; //0.01-1 Default: 1
		var risk = self.getRisk(gRating);
		
		stockPrice = (((growth * staff) / ((risk * risk) + (staff / risk))) / self.getStockAmount()) * stockMOd;
		
		return stockPrice;
		
	};
	
	
	self.setEarnings = function () {
		CAMELOT.store().SMearnings = CAMELOT.gC().cash;
		
	}; 
	
	self.companyWorth = function (){
		
		var enginePrice = CAMELOT.gC().gameLog.last().engine.costs;
		var earnings = CAMELOT.store().SMearnings;
		var staff = CAMELOT.gC().staff.length;
		var stockP = self.getStockPrice();
		var stockA = self.getStockAmount();
		
		var worth = 0;
		
		
		return UI.getShortNumberString(worth);
	};

	self.getRisk = function (rate){
		switch (true){
			case (rate >= 9):
				return 1;
			case (rate >= 8):
				return 1.5;
			case (rate >= 7):
				return 2;
			case (rate >= 6):
				return 3;
			case (rate >= 5):
				return 4;
			case (rate < 5):
				return 5;
			default:
				console.log("getRisk Error");
				return 1;
		}
		console.log("getRisk Error");
		return 1;
	};
	
	self.Interface = (function (self) {


	    self.setSMWindow = function () {
	        var SMWindow = '' +
                '<div id="setSMWindow" class="windowBorder tallWindow" style="overflow:auto;display:none;>' +
                '<div class="windowTitle smallerWindowTitle">Stock Market</div>' +

                '</div>';
	        var findme = document.getElementById("resources");
	        findme.innerHTML += smHtml;
	        /*
            var header  = document.getElementsByTagName('head')[0];
            var linkme  = document.createElement('link');
                    linkme.id   = "gridCss"; linkme.rel  = 'stylesheet'; linkme.type = 'text/css';
                    linkme.href = 'mods/Camelot/Grid/html/grid.css'; //linkme.media = 'all';
                    header.appendChild(linkme);
     */


	    };


	    self.addButton = function (screen, buttonArray) {
	        if (GameManager.company.flags.grid === true && screen == "primary") {
	            buttonArray.push({
	                label: "Stock Market...".localize("menu item"),
	                action: function () {
	                    Sound.click();
	                    self.showMarket();
	                }
	            });
	        }
	    };


	    self.showGrid = function () {

	        var draw = $('#smIterface');

	        draw.css('width', 600);

	        draw.scrollTop();
	        draw.gdDialog({
	            popout: !0,
	            close: !0,
	            onClose: function () {
	                GameManager.togglePause();
	            },
	            onOpen: function () {
	                GameManager.togglePause();
	            }
	        });
	    };



	    self.runStartUp = function () {
	        self.setSMWindow();
	    };

	    return self;
	})(self.Interface || {});


	self.runStartUp = function(){
	    GDT.on(evKey.weekProceeded, self.setEarnings);
		
	};
	
	return self;
})(CAMELOT.StockMarket || {});/*
 * Version: 0.1.0
 * Description: MiscEvent Story Events
 *
 */
CAMELOT.Story = (function (self) {

    self.runStartUp = function () {
        self.Events.Misc.runStartUp();
        self.Events.Grid.runStartUp();
    };




    self.Events = (function (self) {



        self.Misc = (function (self) {

            /*
             * Short Hand Variables
             */
            var evKey = GDT.eventKeys.gameplay;



            /*
             * Event ID's
             */
            var con = "STORY-MISCEVENT-";
            var bailEVID = con += "BAILOUT";
            var betterOfferEVID = con += "BETTEROFFER";

            /*
             * Events
             */

            /*

                VC Funding (Garage - First Office Unlockable)
                A VC looking to invest in a gaming company sees decent run of games, invests 1~5 Million in company (maybe an adjustable bar?)
                VC will want profit % in (1-5 years) for (150~300%) of investment.

                Technology Leak
                Same group who leaks Topics
                Leaks technologies -> Free Research?
                Leaks technologies -> Unlocks research without tech lvl. reaching it?

                Tips Unlocking
                Either a new research option which results in (2-5) research results without having to develop a game
                Costs money
                Event idea -> CEO or staff attends a conference, shares knowledge, random tips/research results are delivered

                Tap Up Staff
                Networking event where CEO meets a recently unemployed 'famous' developer, gives option to hire
                Only available when there is an available slot for staff
                Waives recruitment fee

                Staff Holidays
                Family crisis, wedding, etc. which makes staff goes on holiday without prompt for (1-4 weeks)
                Prompt to allow or reject holiday? Rejection of holiday causes productivity bar to plummet

                Game Studio Visit
                A fan group/university class requests to visit the game studio
                Visit halts any ongoing production, but produces fans
                Rejection of visit reduces fans

                Scandal (Result of Mature Type or 'Action' games?)
                Criminal activity occured that cited "Game" as inspiration
                Option to pay a PR company to reduce negative publicity (- money, 10% chance of fans reducing)
                Appeal to fans to ignore the media hype (50-50 on +/-) fans
                Stay silent (- fans)

                Scandal 2
                CEO approached by a game reviewer about bribing him (10~100k) to give your next game good reviews
                Reject -> + Fans
                Accept -> - Fans, + Hype

            */

















            var bailOut = {
                id: bailEVID,
                isRandom: false,
                maxTriggers: 1,
                trigger: null,
                getNotification: function (company) {
                    var staffMember = CAMELOT.gC().staff.skip(1).pickRandom();
                    CAMELOT.store().bailstaffMember = staffMember.id;
                    var message = staffMember.name + " had a pretty wild night and landed himself in jail. Looks like he won't be joining us again unless you bail him out!".localize().format(staffMember.name);
                    return new Notification({
                        sourceId: bailEVID,
                        header: "Bail!".localize(),
                        text: message,
                        options: ["Bail (5k.)", "Do Nothing"]
                    });
                },
                complete: function (decision) {
                    var nullme = CAMELOT.store().bailstaffMember;
                    var staffMember = CAMELOT.gC().staff.first(function (staff) {
                        return staff.id == nullme;
                    });
                    switch (decision) {
                        case 0:
                            CAMELOT.gC().adjustCash(-5000, "Bail");
                            return CAMELOT.gC().activeNotifications.addRange(new Notification("Bail Made".localize(), staffMember.name + " is a free man once again.".split()));
                        case 1:
                            CAMELOT.gC().flags.fireEmployeeId = nullme;
                            DecisionNotifications.fireEmployee.complete(0);
                            return CAMELOT.gC().activeNotifications.addRange(new Notification("Left in Jail".localize(), staffMember.name + " left the company.").split());
                        default:
                            return CAMELOT.gC().activeNotifications.addRange(new Notification("Bail Out", "There has been an error.").split());
                    }

                }
            };

            var betterOffer = {
                id: betterOfferEVID,
                isRandom: false,
                maxTriggers: 1,
                trigger: null,
                getNotification: function (company) {
                    var staffMember = CAMELOT.gC().staff.skip(1).pickRandom();
                    var salary = staffMember.salary;
                    var raise = salary * 0.3;
                    CAMELOT.store().bostaffMember = staffMember.id;
                    var message = staffMember.name + " did such a good job on that last contract that they now want to hire him! He will stay for a " + raise.toLocaleString() + "Cr. raise.".localize().format(staffMember.name);
                    return new Notification({
                        sourceId: betterOfferEVID,
                        header: "Better Offer...".localize(),
                        text: message,
                        options: ["Offer Raise", "Let Go"]
                    });
                },
                complete: function (decision) {
                    var nullme = CAMELOT.store().bostaffMember;
                    var staffMember = CAMELOT.gC().staff.first(function (staff) {
                        return staff.id == nullme;
                    });
                    var salary = staffMember.salary;
                    switch (decision) {
                        case 0:
                            salary = salary * 1.3;
                            return CAMELOT.gC().activeNotifications.addRange(new Notification("Raise Given".localize(), staffMember.name + " is now being paid " + salary.toLocaleString() + "Cr. a month.").split());
                        case 1:
                            CAMELOT.gC().flags.fireEmployeeId = nullme;
                            DecisionNotifications.fireEmployee.complete(0);
                            return CAMELOT.gC().activeNotifications.addRange(new Notification("Bye Bye".localize(), staffMember.name + " left the company.").split());

                        default:
                            return CAMELOT.gC().activeNotifications.addRange(new Notification("Error", "There has been an error.").split());
                    }
                }
            };




            self.eventLottery = function () {
                if (CAMELOT.store().lotto === false) {
                    if (Math.floor((Math.random() * 170000) + 1) == 1) {
                        var win = Math.floor((Math.random() * 50000000) + 1000000);
                        CAMELOT.post(new Notification("You won the lottery!".localize(), "WOW, You had the winning ticket. You won " + win.toLocaleString() + "Cr."));

                        CAMELOT.store().lotto = true;
                        CAMELOT.gC().adjustCash(win, "Lottery");
                        return;
                    } else {
                        return;
                    }

                }
                GDT.off(evKey.weekProceeded, self.eventLottery);
                return;
            };

            self.stolen = function () {
                if (!(2 >= CAMELOT.gC().flags.evil)) { return; }
                if (CAMELOT.store().stolen !== true) {
                    if (Math.floor((Math.random() * 18000) + 1) != 1) {
                        return;
                    }
                    if (CAMELOT.gC().staff.length == 1) {
                        return;
                    }
                    var staffMember = CAMELOT.gC().staff.skip(1).pickRandom();
                    var cash = CAMELOT.gC().cash;
                    var stolen = cash * 0.05;
                    if (stolen < 0) {
                        return;
                    }
                    CAMELOT.post(new Notification("Stolen!".localize(), "Uh-oh, " + staffMember.name + " walked off with " + stolen.toLocaleString() + "Cr."));
                    CAMELOT.post(new Notification(staffMember.name.localize(), staffMember.name + " left the company."));
                    CAMELOT.gC().adjustCash((stolen * -1), "Stolen!");
                    CAMELOT.gC().flags.fireEmployeeId = staffMember.id;
                    DecisionNotifications.fireEmployee.complete(0);
                    CAMELOT.store().stolen = true;
                }

                GDT.off(evKey.weekProceeded, self.stolen);
                return;

            };

            self.betterOffer = function () {
                if (CAMELOT.store().boRan !== true) {
                    if (CAMELOT.gC().staff.length == 1) {
                        return;
                    }
                    if (Math.floor((Math.random() * 10) + 1) !== 1) {
                        return;
                    }
                    CAMELOT.post(betterOffer.getNotification(CAMELOT.gC()));
                    CAMELOT.store().boRan = true;
                }
                GDT.off(evKey.contractFinished, self.betterOffer);
            };

            self.bailOut = function () {
                if (CAMELOT.store().bailRan !== true) {
                    if (CAMELOT.gC().staff.length === 1) {
                        return;
                    }
                    if (Math.floor((Math.random() * 1500) + 1) !== 1) {
                        return;
                    }

                    CAMELOT.post(bailOut.getNotification(CAMELOT.gC()));
                    CAMELOT.store().bailRan = true;
                }
                GDT.off(evKey.weekProceeded, self.bailOut);
            };

            self.runStartUp = function () {
                //Add Events
                GDT.addEvent(bailOut);
                GDT.addEvent(betterOffer);
                //Set Triggers
                GDT.on(evKey.contractFinished, self.betterOffer);
                GDT.on(evKey.weekProceeded, self.eventLottery);
                GDT.on(evKey.weekProceeded, self.stolen);
                GDT.on(evKey.weekProceeded, self.bailOut);
            };

            return self;
        })(self.Misc || {});

        self.Grid = (function (self) {
            /*
             * Short Hand Variables
             */
            var evKey = GDT.eventKeys.gameplay;

            /*
             * Event ID's
             */
            var con = "STORY-GRID-";
            var comp = con + "COMPETITION";
            var click = con + "KICKSTARTER";
            var modest = con + "MODESTBUNDLE";

            /*
             * Events
             */
            var compEvent = {
                id: comp,
                isRandom: true,
                maxTriggers: 1,
                trigger: null,
                getNotification: function (company) {
                    var message = "N.A. just launched Norigin; a vendor for purchasing and managing games collections just like Grid!";
                    return new Notification({
                        sourceId: comp,
                        header: "N.A. Norigin!".localize(),
                        text: message,
                        options: ["Oh Well", "Buy Them Out (10M.)", "Slur Campaign (100k.)"]
                    });
                },
                complete: function (d) {
                    if (d === 0) {
                        // Reduce "New Content"
                        GridSales.newContentMod();
                        CAMELOT.store().ncMod -= 0.4;
                        return;
                    }
                    if (d === 1) {
                        // Do nothing
                        CAMELOT.gC().adjustCash(1E7, "Slur Campaign");
                        return;
                    }
                    if (d === 2) {
                        // Evil +1
                        CAMELOT.gC().adjustCash(1E5, "Slur Campaign");
                        CAMELOT.gC().flags.evil++;
                        return;
                    }
                    console.log("Borigin Error");
                    return;
                }
            };

            var clickStarter = {
                id: click,
                isRandom: true,
                maxTriggers: 1,
                trigger: null,
                getNotification: function (company) {
                    var message = "An uprising of indie games from Clickstarter means that indie games are super popular now. We'd sell out if we sold anything physical!";
                    return new Notification({
                        sourceId: click,
                        header: "Clickstarter".localize(),
                        text: message,
                        options: ["Sweet!"]
                    });
                },
                complete: function (d) {
                    CAMELOT.store().ncMod += 0.07;
                    return;
                }
            };

            var modestBundle = {
                id: modest,
                isRandom: true,
                maxTriggers: 1,
                trigger: null,
                getNotification: function (company) {
                    var message = "Modest Bundle just launched and they are using Grid Codes to distribute their games. More income for us!";
                    return new Notification({
                        sourceId: modest,
                        header: "Modest Bundle".localize(),
                        text: message,
                        options: ["Great!"]
                    });
                },
                complete: function (d) {
                    CAMELOT.store().ncMod += 0.1;
                    return;
                }
            };

            
            self.modestBundle = function () {
                if (CAMELOT.store().modestRan !== true) {
                    if (CAMELOT.gC().flags.grid !== true) {
                        return;
                    }
                    if (Math.floor((Math.random() * 500) + 1) !== 1) {
                        return;
                    }
                    CAMELOT.post(modestBundle.getNotification(CAMELOT.gC()));
                    CAMELOT.store().modestRan = true;
                }
                GDT.off(evKey.weekProceeded, self.modestBundle);
            };

            self.clickStarter = function () {
                if (CAMELOT.store().clickSRan !== true) {
                    if (CAMELOT.gC().flags.grid !== true) {
                        return;
                    }
                    if (Math.floor((Math.random() * 500) + 1) !== 1) {
                        return;
                    }
                    CAMELOT.post(clickStarter.getNotification(CAMELOT.gC()));
                    CAMELOT.store().clickSRan = true;
                }
                GDT.off(evKey.weekProceeded, self.clickStarter);
            };

            self.compEvent = function () {
                if (CAMELOT.store().orgiRan !== true) {
                    if (CAMELOT.gC().flags.grid !== true) {
                        return;
                    }
                    if (Math.floor((Math.random() * 500) + 1) !== 1) {
                        return;
                    }
                    CAMELOT.post(modestBundle.getNotification(CAMELOT.gC()));
                    CAMELOT.store().orgiRan = true;
                }
                GDT.off(evKey.weekProceeded, self.compEvent);
            };




            self.runStartUp = function () {
                //Add Events
                GDT.addEvent(modestBundle);
                GDT.addEvent(clickStarter);
                GDT.addEvent(compEvent);

                //Set Triggers
                GDT.on(evKey.weekProceeded, self.modestBundle);
                GDT.on(evKey.weekProceeded, self.clickStarter);
                GDT.on(evKey.weekProceeded, self.compEvent);
            };


            return self;
        })(self.Grid || {});

        return self;
    })(self.Events || {});





















	return self;
})(CAMELOT.Story || {});(function () {
    //Run CAMELOT start up functions
	CAMELOT.runStartUp();
	CAMELOT.Train.runStartUp();
	CAMELOT.Debug.runStartUp();
	CAMELOT.Specialism.runStartUp();
	CAMELOT.MiscFeatures.runStartUp();
	CAMELOT.StartingMoney.runStartUp();
	CAMELOT.Grid.runStartUp();
	CAMELOT.GameMode.runStartUp();
	CAMELOT.Story.runStartUp();

})();